import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth-utils";
import { prisma } from "@/lib/prisma";

/**
 * GET /api/admin/jobs
 * Query: page, limit, search, category, location (JSON), status
 * Backend pagination and filters for admin job management.
 */
export async function GET(req: NextRequest) {
  try {
    await requireAdmin();

    const searchParams = req.nextUrl.searchParams;
    const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get("limit") || "10", 10)));
    const search = (searchParams.get("search") || "").trim();
    const category = (searchParams.get("category") || "").trim();
    const status = (searchParams.get("status") || "").trim();
    let country = (searchParams.get("country") || "").trim();
    let state = (searchParams.get("state") || "").trim();
    let city = (searchParams.get("city") || "").trim();
    const locationParam = searchParams.get("location") || "";
    if (locationParam) {
      try {
        const loc = JSON.parse(decodeURIComponent(locationParam)) as {
          country?: string;
          state?: string;
          city?: string;
        };
        if (loc.country) country = loc.country.trim();
        if (loc.state) state = loc.state.trim();
        if (loc.city) city = loc.city.trim();
      } catch {
        // ignore invalid JSON
      }
    }

    const andParts: Array<Record<string, unknown>> = [];

    if (search) {
      andParts.push({
        OR: [
          { title: { contains: search, mode: "insensitive" as const } },
          { description: { contains: search, mode: "insensitive" as const } },
        ],
      });
    }
    if (category) andParts.push({ category });
    if (status) {
      andParts.push({
        status: status as "PENDING" | "ACTIVE" | "INACTIVE" | "PAUSED" | "CLOSED",
      });
    }
    if (country) {
      andParts.push({
        location: {
          contains: `"country":"${country.replace(/"/g, '\\"')}"`,
          mode: "insensitive" as const,
        },
      });
    }
    if (state) {
      andParts.push({
        location: {
          contains: `"state":"${state.replace(/"/g, '\\"')}"`,
          mode: "insensitive" as const,
        },
      });
    }
    if (city) {
      andParts.push({
        location: {
          contains: `"city":"${city.replace(/"/g, '\\"')}"`,
          mode: "insensitive" as const,
        },
      });
    }

    const where = andParts.length > 0 ? { AND: andParts } : {};

    const [total, jobs] = await Promise.all([
      prisma.job.count({ where }),
      prisma.job.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * limit,
        take: limit,
        include: {
          employer: {
            select: {
              companyName: true,
              companyLogo: true,
              industry: true,
              companySize: true,
              description: true,
            },
          },
          _count: { select: { applications: true } },
        },
      }),
    ]);

    const totalPages = Math.ceil(total / limit);

    return NextResponse.json({
      jobs: jobs.map((j) => ({
        id: j.id,
        title: j.title,
        location: j.location,
        category: j.category,
        status: j.status,
        createdAt: j.createdAt,
        employer: j.employer,
        _count: j._count,
      })),
      total,
      totalPages,
      page,
      limit,
    });
  } catch (e) {
    console.error("[GET /api/admin/jobs]", e);
    return NextResponse.json(
      { error: "Failed to fetch jobs." },
      { status: 500 }
    );
  }
}
